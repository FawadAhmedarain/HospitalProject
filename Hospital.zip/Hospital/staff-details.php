<!DOCTYPE html>
<?php include("func.php"); ?>
<html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.0/css/bootstrap.min.css" integrity="sha384-SI27wrMjH3ZZ89r4o+fGIJtnzkAnFs3E4qz9DIYioCQ5l9Rd/7UAa8DHcaL8jkWt" crossorigin="anonymous">

</head>
<body>
<div class="jumbotron" style="background:url('images/3.jpg') no-repeat;  background-size:cover; height: 300px"></div>

<div class="container-fluid">
	<div class="row">
	
		<div class="col-md-3">
			<div class="list-group">
				<a href="" class="list-group-item active" style="background-color:#3498D8;color:#ffffff; border-color:#3498D8; ">Staff Details</a>
				<a href="doctors-details.php" class="list-group-item ">Doctors</a>
			<!-- 	<a href="" class="list-group-item ">Add New Patient</a> -->
				<a href="xray-staff.php" class="list-group-item ">X-Ray Staff</a>
				<a href="counter-staff.php" class="list-group-item ">Counter Staff</a>
				<a href="sweeper.php" class="list-group-item ">Sweepers</a>
				<a href="guard.php" class="list-group-item ">Guards</a>
			</div>
			<hr>
			
		</div>
		<div class="col-md-8">
			<div class="card" >
				<div class="col-md-1">	
			<a href="admin-panel.php" class="btn btn-light" style="width: 90px">Go Back</a>
		</div>
				<div class="crad-body" style="background-color:#3498D8;color:#ffffff; height: 50px;text-align: center; padding-top: 15px" >
					Staff Details
				</div>
			<div class="crad-body" style="background-color:#3498D8;color:#ffffff;  ">
				<table id="table1" class="table table-hover">
  <thead>
    <tr>
     <!--  <th scope="col">#</th>
 -->      <th scope="col">Doctors</th>
      <th scope="col">X-Ray Staff</th>
      <th scope="col">Counter Staff</th>
      <th scope="col">Sweepers</th>
      <th scope="col">Gurds</th>
      
    </tr>
  </thead>
  <tbody>
   <?php get_staff_details(); ?>

    
  </tbody>
</table>


			</div>

			</div>

		</div>
		<div class="col-md-1"></div>

	</div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.0/js/bootstrap.min.js" integrity="sha384-3qaqj0lc6sV/qpzrc1N5DC6i1VRn/HyX4qdPaiEFbn54VjQBEU341pvjz7Dv3n6P" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9.4.1/dist/sweetalert2.all.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/8.11.8/sweetalert2.min.js"></script>

</body>
</html>
<!DOCTYPE html>
<?php include("func.php"); ?>
<html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.0/css/bootstrap.min.css" integrity="sha384-SI27wrMjH3ZZ89r4o+fGIJtnzkAnFs3E4qz9DIYioCQ5l9Rd/7UAa8DHcaL8jkWt" crossorigin="anonymous">

</head>
<body>
<div class="jumbotron" style="background:url('images/3.jpg') no-repeat;  background-size:cover; height: 300px"></div>

<div class="container-fluid">
	<div class="row">
	
		<div class="col-md-3">
			<div class="list-group">
				<a href="" class="list-group-item active" style="background-color:#3498D8;color:#ffffff; border-color:#3498D8; ">Patients</a>
				<a href="patient-details.php" class="list-group-item ">Patient Details</a>
			<!-- 	<a href="" class="list-group-item ">Add New Patient</a> -->
				<a href="checkout.php" class="list-group-item ">Payment/Checkout</a>
			</div>
			<hr>
			<div class="list-group">
				<a href="" class="list-group-item active" style="background-color:#3498D8;color:#ffffff; border-color:#3498D8; ">Staff</a>
				<a href="staff-details.php" class="list-group-item ">Staff Details</a>
				<a href="staff-details.php" class="list-group-item ">Add New Staff</a>
				
			</div>
		</div>
		<div class="col-md-8">
			<div class="card" >
				<div class="crad-body" style="background-color:#3498D8;color:#ffffff; height: 50px;text-align: center; padding-top: 15px" >
					 Book an Appointment
				</div>
			<div class="crad-body">
				<form class="form-group" action="func.php" method="post">
					<label>First Name : </label>

					<input type="text" name="fname" class="form-control" required="required" ><br>
					<label>Last Name : </label>
					<input type="text" name="lname" class="form-control" required="required"><br>
					<label>Email id : </label>
					<input type="email" name="email" class="form-control" required="required"><br>
					<label>Contact : </label>

<input type="text" name="contact" class="form-control"  title="Enter valid number and 11 digit " pattern="[0-9]{11}" required ><br>
					<label>Doctor Appointment : </label>
					<select class="form-control " name="docapp">
						<!-- <option value="Dr Waqar 1pm to 5pm">Dr Waqar 1pm to 5pm</option>
						<option value="Dr Aliyan 3pm to 6pm">Dr Aliyan 3pm to 6pm</option>
						<option value="Dr Hina 5pm to 7pm">Dr Hina 5pm to 7pm</option> -->
                    <?php display_doctor(); ?>
					</select><br>
					<label>Appointment Date : </label>
					 <input type="text" name="date" placeholder="YYYY-MM-DD" required 
pattern="(?:19|20)[0-9]{2}-(?:(?:0[1-9]|1[0-2])-(?:0[1-9]|1[0-9]|2[0-9])|(?:(?!02)(?:0[1-9]|1[0-2])-(?:30))|(?:(?:0[13578]|1[02])-31))" 
title="Enter a date in this format YYYY-MM-DD" class="form-control" /><br>
					
					<label>Payment : </label>
					<input type="text" name="payment" class="form-control" required="required"><br>
                    <input type="submit" class="btn btn-primary" name="pat_submit" value="Enter Appointment">
				</form>


			</div>

			</div>

		</div>
		<div class="col-md-1"></div>

	</div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.0/js/bootstrap.min.js" integrity="sha384-3qaqj0lc6sV/qpzrc1N5DC6i1VRn/HyX4qdPaiEFbn54VjQBEU341pvjz7Dv3n6P" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9.4.1/dist/sweetalert2.all.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/8.11.8/sweetalert2.min.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
Swal.fire({
  title: 'Welcome!',
  text: 'Have a nice day!',
  imageUrl: 'images/6.jpg',
  imageWidth: 300,
  imageHeight: 200,
  imageAlt: 'Custom image',
})
	});
</script>
</body>
</html>
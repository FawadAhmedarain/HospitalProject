<!DOCTYPE html>
<?php include("func.php"); ?>
<html>
<head>
	<title>Patient Details</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.0/css/bootstrap.min.css" integrity="sha384-SI27wrMjH3ZZ89r4o+fGIJtnzkAnFs3E4qz9DIYioCQ5l9Rd/7UAa8DHcaL8jkWt" crossorigin="anonymous">
</head>
<body>
<div class="jumbotron" style="background:url('images/3.jpg') no-repeat;  background-size:cover; height: 300px"></div>

<div class="container">
	<div class="card">
		<div class="crad-body" style="background-color:#3498D8;color:#ffffff;  padding-top: 17px" >
			<div class="row">
			<div class="col-md-1">	
			<a href="admin-panel.php" class="btn btn-light" style="width: 90px">Go Back</a>
		</div>
			<div class="col-md-3"><h3>Patient Details</h3></div>
			<div class="col-md-8">
				<form class="form-group" action="search-patient.php" method="Post">
					<div class="row">
				<div class="col-md-10">	<input type="text" id="search" name="search" class="form-control" placeholder="Enter Contact "></div>
			<div class="col-md-2">		<input type="submit" name="patient_search_submit" class="btn btn-light" value="Search"></div></div>
				</form>

			</div>
				</div></div>
					<div class="crad-body" style="background-color:#3498D8;color:#ffffff;  ">
					<table id="table1" class="table table-hover">
  <thead>
    <tr>
     <!--  <th scope="col">#</th>
 -->      <th scope="col">First Name</th>
      <th scope="col">Last Name</th>
      <th scope="col">Email Id</th>
      <th scope="col">Contact</th>
      <th scope="col">Doctor Appointment</th>
       <th scope="col">Date</th>
      <th scope="col">Doctor Appointment</th>
    </tr>
  </thead>
  <tbody>
   <?php get_patient_details(); ?>
    
  </tbody>
</table>
</div>
	</div>


</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.0/js/bootstrap.min.js" integrity="sha384-3qaqj0lc6sV/qpzrc1N5DC6i1VRn/HyX4qdPaiEFbn54VjQBEU341pvjz7Dv3n6P" crossorigin="anonymous"></script>

<script >
	var table=document.getElementById('table1'),rIndex;
for (var i = 0 ; i < table.rows.length; i++) {
table.rows[i].onclick=function() {
	// body...
	rIndex= this.rowIndex;
	document.getElementById("search").value = this.cells[3].innerHTML;
};
}

</script>
</body>
</html>
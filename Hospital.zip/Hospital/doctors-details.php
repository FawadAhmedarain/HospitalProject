<!DOCTYPE html>
<?php include("func.php"); ?>
<html>
<head>
	<title>Doctor Details</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.0/css/bootstrap.min.css" integrity="sha384-SI27wrMjH3ZZ89r4o+fGIJtnzkAnFs3E4qz9DIYioCQ5l9Rd/7UAa8DHcaL8jkWt" crossorigin="anonymous">
</head>
<body>
<div class="jumbotron" style="background:url('images/3.jpg') no-repeat;  background-size:cover; height: 300px"></div>

<div class="container">
	<div class="card">
		<!-- Default unchecked -->

<div class="modal fade" id="modalLoginForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header text-center">
        <h4 class="modal-title w-100 font-weight-bold">Add New Doctor</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body mx-3">
      	<div class="card">
		<img src="images/1.jpg" class="card-img-top">

        <div class="md-form mb-5">
          <i class="fas fa-envelope prefix grey-text"></i>
          <form action="func.php" method="post">
           <label>Name</label>
          <input type="text" id="defaultForm-email" name="name" class="form-control "required="required"><br>
          <label >Address</label>
          <input type="text" id="defaultForm-email" name="address" class="form-control "required="required"><br>
            <label>Id</label>
          <input type="text" id="defaultForm-email" name="id" class="form-control "required="required"><br>
          <label >Cnic</label>
          <input type="text" id="defaultForm-email" name="cnic" class="form-control " title="Enter valid nic number and 14 digit " pattern="[0-9]{14}" required><br>
            <label>Contact</label>
          <input type="text" id="defaultForm-email" name="contact" class="form-control " title="Enter valid number and 11 digit " pattern="[0-9]{11}" required><br>
          <label >Salary</label>
          <input type="text" id="defaultForm-email" name="salary" class="form-control "required="required"><br>
            <label>Spasalist</label>
          <input type="text" id="" name="spalist" class="form-control "required="required"><br>
        
        </div>
      </div>
      <div class="modal-footer d-flex justify-content-center">
       <input type="submit" name="insert" value="Insert Doctor Staff" id="d1" class="btn btn-primary">
   </form>
      </div></div>
    </div>
  </div>
</div>

<div class="text-center" style="background-color:#grey;  padding-top: 17px">
  <a href="" class="btn btn-primary btn-rounded mb-4" data-toggle="modal" data-target="#modalLoginForm">Add New Doctors</a>
</div>
		<div class="crad-body" style="background-color:#3498D8;color:#ffffff;  padding-top: 17px" >
			<div class="row">
			<div class="col-md-1">	
			<a href="staff-details.php" class="btn btn-light" style="width: 90px">Go Back</a>

		</div>
			<div class="col-md-3"><h3>Doctor  Details</h3></div>
			<div class="col-md-8">
				<form class="form-group" action="doctors-details.php" method="Post">
					<div class="row">
				<div class="col-md-10">	<input type="text" id="delete" name="delete" class="form-control" placeholder="Enter cnic for delete doctor  records "></div>
			<div class="col-md-2">		<input type="submit" name="delete_submit" class="btn btn-danger" value="Delete "></div></div>
				</form>

			</div>
				</div></div>
					<div class="crad-body" style="background-color:#3498D8;color:#ffffff;  ">
					<table id="table1" class="table table-hover">
  <thead>
    <tr>
     <!--  <th scope="col">#</th>

 -->    
  <th scope="col">Doctor Name</th>
    <th scope="col">Address</th>
   <th scope="col">id</th>
    
      <th scope="col">Cnic</th>
      <th scope="col">Contact</th>
      <th scope="col">Salary</th>
       <th scope="col">Spasalist In</th>
    
  
    </tr>
  </thead>
  <tbody>
   <?php get_doctor_details(); ?>
    
  </tbody>
</table>
</div>
	</div>


</div>
<?php 

if (isset($_POST['delete_submit'])) {
$cni=$_POST['delete'];
	$query="DELETE from docttb where cnic='$cni'";
	$result=mysqli_query($con,$query);
	if($result){
		
	// echo "<script>window.open('search-patient.php','_self');</script>";
		  echo "<script>alert('Delete Record');</script>";
	echo "<script>window.open('doctors-details.php','_self');</script>";
	}
}
?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.0/js/bootstrap.min.js" integrity="sha384-3qaqj0lc6sV/qpzrc1N5DC6i1VRn/HyX4qdPaiEFbn54VjQBEU341pvjz7Dv3n6P" crossorigin="anonymous"></script>

<script >
	var table=document.getElementById('table1'),rIndex;
for (var i = 0 ; i < table.rows.length; i++) {
table.rows[i].onclick=function() {
	// body...
	rIndex= this.rowIndex;
	document.getElementById("delete").value = this.cells[3].innerHTML;
};
}

</script>
</body>
</html>
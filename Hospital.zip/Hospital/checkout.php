<!DOCTYPE html>
<?php include("func.php"); ?>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.0/css/bootstrap.min.css" integrity="sha384-SI27wrMjH3ZZ89r4o+fGIJtnzkAnFs3E4qz9DIYioCQ5l9Rd/7UAa8DHcaL8jkWt" crossorigin="anonymous">
</head>
<body>

<div class="container">
	<div class="card">
		<div class="crad-body" style="background-color:#3498D8;color:#ffffff;  padding-top: 17px" >
			<div class="row">
			<div class="col-md-1">	
			<a href="admin-panel.php" class="btn btn-light" style="width: 90px">Go Back</a>
		</div>
			<div class="col-md-3"><h3>Payment/Checkout</h3></div>
			<div class="col-md-8">
				<form class="form-group" action="checkout.php" method="Post">
					<div class="row">
				<div class="col-md-10">	<input type="text" name="search" class="form-control" placeholder="Enter Contact for  receipt" required="required" ></div>
			<div class="col-md-2">		<input type="submit" name="check_search_submit" class="btn btn-light" value="Search"></div></div>
				</form>

			</div>
				</div></div>
<div  class="container" style="width: 500px;margin-top: 100px">
	<div class="card" id="printMe">
		<img src="images/1.jpg" class="card-img-top"><br>
        <center><h3 class="card" style="color: #3252a8">Hospital Management System</h3></center>
		<div class="card-body">
	<div class="container">
    <div class="row">
        <div class="well col-xs-10 col-sm-10 col-md-6 col-xs-offset-1 col-sm-offset-1 col-md-offset-3">
            <div class="row">
                <div class="col-xs-6 col-sm-6 col-md-6">
                    <address>
                        <!-- <strong>Elf Cafe</strong>
                        <br />
                        2135 Sunset Blvd
                        <br />
                        Los Angeles, CA 90026
                        <br />
                        <abbr title="Phone">P:</abbr> (213) 484-6829 -->
                    <?php

if (isset($_POST['search'])) {

                     display_date(); } ?>
                    </address>
                </div>
                <div class="col-xs-6 col-sm-6 col-md-6 text-right">
                  <!--   <p>
                        <em>Date: 1st November, 2013</em>
                    </p>
                    <p>
                        <em>Receipt #: 34522677W</em>
                    </p> -->

                      <?php 
if (isset($_POST['search'])) {
                        display_address(); } ?>
                     
                </div>

            </div>
            <div class="row">
                <div class="text-center">
                    <h1>Receipt</h1>
                </div>
                
                <table class="table table-hover">
                    <thead>
                       <!--  <tr>
                            <th>Product</th>
                                                   <th class="text-center">Price</th>
                            <th class="text-center">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="col-md-9"><em>Baked </em></td>
                            <td class="col-md-1" style="text-align: center"> 2 </td>
                            <td class="col-md-1 text-center">$13</td>
                        
                        </tr>
                        
                      
                       
                        <tr>
                         
                            <td class="text-right"><h4><strong>Total: </strong></h4></td>
                            <td class="text-center text-danger"><h4><strong>$31.53</strong></h4></td>
                        </tr> -->
                        <?php

if (isset($_POST['search'])) {
                         display_payment();} ?>
                    </tbody>
                </table>


               


          
            </div>
        </div>
    </div>
</div>
	</div>
	</div>



<br>

      <button type="button" onclick="printDiv('printMe')" class="btn btn-primary btn-lg ">Pay Now <span class="glyphicon glyphicon-chevron-right" ></span></button>


                <script>

    function printDiv(divName){
            var printContents = document.getElementById(divName).innerHTML;
            var originalContents = document.body.innerHTML;
            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
        }
</script>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.0/js/bootstrap.min.js" integrity="sha384-3qaqj0lc6sV/qpzrc1N5DC6i1VRn/HyX4qdPaiEFbn54VjQBEU341pvjz7Dv3n6P" crossorigin="anonymous"></script>
</body>
</html>
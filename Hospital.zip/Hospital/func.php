<?php

$con=mysqli_connect("localhost","root","","hmdb");
if(isset($_POST['login_submit'])){

$username=$_POST['username'];
$password=$_POST['password'];
	$query="select * from login where username='$username' and password='$password'";
	$result=mysqli_query($con, $query);

	if (mysqli_num_rows($result)==1) {
		header("location:admin-panel.php");
	}else
	  echo "<script>alert('Enter correct username and password');</script>";
	echo "<script>window.open('index.php','_self');</script>";

}

if (isset($_POST['pat_submit'])) {
	$fname=$_POST['fname'];
	$lname=$_POST['lname'];
	$email=$_POST['email'];
	$contact=$_POST['contact'];
	$docapp=$_POST['docapp'];
	$date=$_POST['date'];
	$payment=$_POST['payment'];
	$query="insert into doctorapp(fname,lname,email,contact,docapp,date,payment)values('$fname','$lname','$email','$contact','$docapp','$date','$payment')";
	$result=mysqli_query($con,$query);
	if($result){
		 echo "<script>alert('Appointment Registerd.');</script>";
	echo "<script>window.open('admin-panel.php','_self');</script>";
	}
}


if (isset($_POST['guardinserted'])) {
	$id=$_POST['id'];
	$name=$_POST['name'];
	$address=$_POST['address'];
	$contact=$_POST['contact'];
	$nic=$_POST['nic'];
	$salary=$_POST['salary'];
	$date=$_POST['date'];
	$query="insert into guard(id,name,address,contact,nic,salary,date)values('$id','$name','$address','$contact','$nic','$salary','$date')";
	$result=mysqli_query($con,$query);
	if($result){
		 echo "<script>alert('New guard data is inserted.');</script>";
	echo "<script>window.open('guard.php','_self');</script>";
	}
}

if (isset($_POST['addedsweeper'])) {
	$id=$_POST['id'];
	$name=$_POST['name'];
	$address=$_POST['address'];
	$contact=$_POST['contact'];
	$nic=$_POST['nic'];
	$salary=$_POST['salary'];
	$date=$_POST['date'];

	$query="insert into sweeper(id,name,address,contact,nic,salary,date)values('$id','$name','$address','$contact','$nic','$salary','$date')";
	$result=mysqli_query($con,$query);
	if($result){
		 echo "<script>alert('New Sweeper Staff Data is  added.');</script>";
	echo "<script>window.open('sweeper.php','_self');</script>";
	}
}

if (isset($_POST['counteradd'])) {
	$id=$_POST['id'];
	$name=$_POST['name'];
	$counter=$_POST['counter'];
	$address=$_POST['address'];
	$contact=$_POST['contact'];
	$nic=$_POST['nic'];
	$salary=$_POST['salary'];
	$date=$_POST['date'];
	
	$query="insert into counter(id,name,counter,address,contact,nic,salary,date)values('$id','$name','$counter','$address','$contact','$nic','$salary','$date')";
	$result=mysqli_query($con,$query);
	if($result){
		 echo "<script>alert('Counter Staff Data is added.');</script>";
	echo "<script>window.open('counter-staff.php','_self');</script>";
	}
}

if (isset($_POST['insert'])) {
	$name=$_POST['name'];
	$address=$_POST['address'];
	$id=$_POST['id'];
	$cnic=$_POST['cnic'];
	$contact=$_POST['contact'];
	$salary=$_POST['salary'];
	$spalist=$_POST['spalist'];
	$query="insert into docttb(name,address,id,cnic,contact,salary,spalist)values('$name','$address','$id','$cnic','$contact','$salary','$spalist')";
	$result=mysqli_query($con,$query);
	if($result){
		 echo "<script>alert('Doctor Data Inserted.');</script>";
	echo "<script>window.open('doctors-details.php','_self');</script>";
	}
}

if (isset($_POST['xraydata'])) {
	$id=$_POST['id'];
	$name=$_POST['name'];
	$nic=$_POST['nic'];
	$contact=$_POST['contact'];
	$address=$_POST['address'];
	$salary=$_POST['salary'];
	$date=$_POST['date'];

	$query="insert into xray(id,name,nic,contact,address,salary,date)values('$id','$name','$nic','$contact','$address','$salary','$date')";
	$result=mysqli_query($con,$query);
	if($result){
		 echo "<script>alert('Insert Xray Staff Data .');</script>";
	echo "<script>window.open('xray-staff.php','_self');</script>";
	}
}

if (isset($_POST['reset'])) {
	$username=$_POST['username'];
	$password=$_POST['password'];

	$query="UPDATE login SET username = '$username', password= '$password'WHERE username ='$username';";
	$result=mysqli_query($con,$query);
	if($result){
		 echo "<script>alert('Password is resert.');</script>";
	echo "<script>window.open('index.php','_self');</script>";
	}
}





function get_patient_details(){
	global  $con;
	$query="select * from doctorapp";
	$result=mysqli_query($con,$query);
	while ($row=mysqli_fetch_array($result)) {
	$fname=$row['fname'];
	$lname=$row['lname'];
	$email=$row['email'];
	$contact=$row['contact'];
	$docapp=$row['docapp'];
	$date=$row['date'];
	$payment=$row['payment'];
	echo " <tr>
    
      <td>$fname</td>
      <td>$lname</td>
      <td>$email</td>
      <td>$contact</td>
      <td>$docapp</td>
        <td>$date</td>
      <td>$payment</td>
    </tr>";
	}
}


function display_doctor(){

	global $con;
	$query="select * from docttb";
	$result=mysqli_query($con,$query);
	while ($row=mysqli_fetch_array($result)) {
	$name=$row['name'];

	echo "<option value='$name'>$name</option>";
}
}


function display_date(){

global $con;

 $contact=$_POST['search'];
  $query="select * from doctorapp where contact='$contact'";
	$result=mysqli_query($con,$query);
	while ($row=mysqli_fetch_array($result)) {
	$fname=$row['fname'];
	$lname=$row['lname'];
	$contact=$row['contact'];
	$docapp=$row['docapp'];
	$date=$row['date'];
	$payment=$row['payment'];
$random=rand(1,100);

	echo "
<p>Receipt#:$random</p>
	<p>Name:$fname $lname        </p>
                    <p>
                     Contact:  $contact
                    </p>";

}
}


function display_address(){

global $con;

 $contact=$_POST['search'];
  $query="select address from hospitaladd;";
	$result=mysqli_query($con,$query);
	while ($row=mysqli_fetch_array($result)) {
	$address=$row['address'];
	

	echo "<p>
      Address: $address
                    </p>
                   ";

}
}


function display_payment(){
global $con;
$contact=$_POST['search'];
  $query="select * from doctorapp where contact='$contact'";
	$result=mysqli_query($con,$query);
	while ($row=mysqli_fetch_array($result)) {
	$fname=$row['fname'];
	$lname=$row['lname'];
	$contact=$row['contact'];
	$docapp=$row['docapp'];
	$date=$row['date'];
	$payment=$row['payment'];

	echo " <tr>
                            <th>Doctor </th>
                                                   <th class='text-center'>Date</th>
                            <th class='text-center'>Payment</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class='col-md-9'><em>$docapp </em></td>
                            <td class='col-md-1' style='text-align: center'> $date </td>
                            <td class='col-md-1 text-center'>Rs$payment</td>
                        
                        </tr>
                        
                      
                       
                        <tr>
                         
                            <td class='text-right'><h4><strong>Total: </strong></h4></td>
                            <td class='text-center text-danger'><h4><strong>RS$payment</strong></h4></td>
                        </tr>";

}
}



function get_staff_details(){
	global  $con;
	$query="select * from staff";
	$result=mysqli_query($con,$query);
	while ($row=mysqli_fetch_array($result)) {
	$doctor=$row['doctors'];
	$xray=$row['xray'];
	$counter=$row['counter'];
	$sweeper=$row['sweeper'];
	$guard=$row['guard'];
	
	echo " <tr>
    
      <td>$doctor</td>
      <td>$xray</td>
      <td>$counter</td>
      <td>$sweeper</td>
      <td>$guard</td>
   
    </tr>";
	}
}


function get_doctor_details(){
	global  $con;
	$query="select * from docttb";
	$result=mysqli_query($con,$query);
	while ($row=mysqli_fetch_array($result)) {
	$name=$row['name'];
	$address=$row['address'];
	$id=$row['id'];
	$cnic=$row['cnic'];
	$contact=$row['contact'];
	$salary=$row['salary'];
	$spalist=$row['spalist'];

	
	echo " <tr>
    
      <td>$name</td>
      <td>$address</td>
      <td>$id</td>
      <td>$cnic</td>
      <td>$contact</td>
       <td>$salary</td>
      <td>$spalist</td>
         
  
    </tr>";
	}
}


function get_xray_details(){
	global  $con;
	$query="select * from xray";
	$result=mysqli_query($con,$query);
	while ($row=mysqli_fetch_array($result)) {
	$id=$row['id'];
	$name=$row['name'];
	$nic=$row['nic'];
	$contact=$row['contact'];
	$address=$row['address'];
	$salary=$row['salary'];
	$date=$row['date'];

	
	echo " <tr>
      <td>$id</td>
      <td>$name</td>
      <td>$nic</td>
      <td>$contact</td>
      <td>$address</td>
      <td>$salary</td>
      <td>$date</td>
         
  
    </tr>";
	}
}



function get_counter_details(){
	global  $con;
	$query="select * from counter";
	$result=mysqli_query($con,$query);
	while ($row=mysqli_fetch_array($result)) {
	$id=$row['id'];
	$name=$row['name'];
	$counter=$row['counter'];
	$address=$row['address'];
	$contact=$row['contact'];
	$nic=$row['nic'];
    $salary=$row['salary'];
	$date=$row['date'];
	
	

	
	echo " <tr>
      <td>$id</td>
      <td>$name</td>
      <td>$counter</td>
      <td>$address</td>
      <td>$contact</td>
      <td>$nic</td>
      <td>$salary</td>
      <td>$date</td>
         
  
    </tr>";
	}
}


function get_sweeper_details(){
	global  $con;
	$query="select * from sweeper";
	$result=mysqli_query($con,$query);
	while ($row=mysqli_fetch_array($result)) {
	$id=$row['id'];
	$name=$row['name'];
	$address=$row['address'];
	$contact=$row['contact'];
	$nic=$row['nic'];
    $salary=$row['salary'];
	$date=$row['date'];
	
	

	
	echo " <tr>
      <td>$id</td>
      <td>$name</td>
      <td>$address</td>
      <td>$contact</td>
      <td>$nic</td>
      <td>$salary</td>
      <td>$date</td>
         
  
    </tr>";
	}
}

function get_guard_details(){
	global  $con;
	$query="select * from guard";
	$result=mysqli_query($con,$query);
	while ($row=mysqli_fetch_array($result)) {
	$id=$row['id'];
	$name=$row['name'];
	$address=$row['address'];
	$contact=$row['contact'];
	$nic=$row['nic'];
    $salary=$row['salary'];
	$date=$row['date'];
	
	

	
	echo " <tr>
      <td>$id</td>
      <td>$name</td>
      <td>$address</td>
      <td>$contact</td>
      <td>$nic</td>
      <td>$salary</td>
      <td>$date</td>
         
  
    </tr>";
	}
}
?>
-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 04, 2019 at 11:45 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hmdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`address`) VALUES
('Liquat Medical Hospital Jamshoro\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `counter`
--

CREATE TABLE `counter` (
  `id` varchar(20) NOT NULL,
  `name` varchar(40) NOT NULL,
  `counter` varchar(40) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact` varchar(60) NOT NULL,
  `nic` varchar(100) NOT NULL,
  `salary` varchar(100) NOT NULL,
  `date` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `counter`
--

INSERT INTO `counter` (`id`, `name`, `counter`, `address`, `contact`, `nic`, `salary`, `date`) VALUES
('ka12a', 'Kasif  Ali', 'Placed At counter number 1', 'House no 5 near Sir Sayed University gulshn Iqbal Karachi ', '03345243452', '40494344123567', '10000', '12-01-2005'),
('hibc2', 'Hiba Shah', 'Place at Counter Number 2', 'House no 8 near B.K School Malir Karachi', '03394556678', '44067445611234', '10000', '12-01-2005'),
('akac3', 'Aktar Ali', 'Placed at Counter number 3', 'House no 1 near Agha khan Labortory Qaidabad Karachi', '03345461212', '40445456343457', '10000', '12-01-2005');

-- --------------------------------------------------------

--
-- Table structure for table `doctorapp`
--

CREATE TABLE `doctorapp` (
  `fname` varchar(40) NOT NULL,
  `lname` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `contact` varchar(40) NOT NULL,
  `docapp` varchar(60) NOT NULL,
  `date` varchar(80) NOT NULL,
  `payment` int(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctorapp`
--

INSERT INTO `doctorapp` (`fname`, `lname`, `email`, `contact`, `docapp`, `date`, `payment`) VALUES
('Shazia', 'Nadeem', 'shaziana@gmail.com', '033333512132', 'Dr Aliyan 3pm to 6pm', '28-11-2019', 1200),
('Ali ', 'Hassan', 'alihassan78@gmail.com', '03312989867', 'Dr Waqar 1pm to 5pm', '27-11-2019', 1000),
('Asma', 'ALi', 'asma@gmail.com', '03345678903', 'Dr Aliyan 3pm to 6pm', '31-11-2019', 1000);

-- --------------------------------------------------------

--
-- Table structure for table `docttb`
--

CREATE TABLE `docttb` (
  `name` varchar(60) NOT NULL,
  `address` varchar(100) NOT NULL,
  `id` varchar(40) NOT NULL,
  `cnic` varchar(40) NOT NULL,
  `contact` varchar(40) NOT NULL,
  `salary` varchar(40) NOT NULL,
  `spalist` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `docttb`
--

INSERT INTO `docttb` (`name`, `address`, `id`, `cnic`, `contact`, `salary`, `spalist`) VALUES
('Dr Waqar 1pm to 5pm', 'House no d12 near denence karachi', 'waq101', '44534536576812', '03334567890', '30000', 'Child'),
('Dr Hina 5pm to 7pm', 'Malir 15 house no M12 karachi', 'hin102', '44413231323132', '03234567891', '25000', 'Ganiocalogist'),
('Dr Aliyan 3pm to 6pm', 'Qaidaba house no q32 near madina town karachi', 'ali103', '40234567891234', '03056451324', '20000', 'Skin'),
('Dr Hiba 8pm to 10pm', 'Gulshana Iqbal house no g12 karachi', 'hib104', '44120098908890', '03123777892', '50000', 'Sergon'),
('Dr Iftikhar 11am to 1pm', 'Kalaboard near malir15 KARACHI', 'IFI105', '40129998765456', '03452187907', '50000', 'Sergon');

-- --------------------------------------------------------

--
-- Table structure for table `guard`
--

CREATE TABLE `guard` (
  `id` varchar(40) NOT NULL,
  `name` varchar(40) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact` varchar(60) NOT NULL,
  `nic` varchar(60) NOT NULL,
  `salary` varchar(40) NOT NULL,
  `date` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `guard`
--

INSERT INTO `guard` (`id`, `name`, `address`, `contact`, `nic`, `salary`, `date`) VALUES
('ans01', 'Anser Ali', 'Muhla Nsimabad near digroar karachi', '03300098989', '44408787879087', '8000', '02-02-2002'),
('bil02', 'Bilal Ahmed', 'Nasimabas nears kuranugi karachi', '03346666776', '44481213232423', '8000', '02-02-2002'),
('asa03', 'Asad Ali', 'Gulsjan Iqbal block 5  university road karachi', '03349012786', '44099811123278', '8000', '02-02-2002'),
('Iqb04', 'Iqbbal Ahmed', 'House no 5gali number 5 layari karachi', '03050091234', '44465442879890', '8000', '01-01-2002'),
('waq05', 'Waqas Ali', 'Muhala Gribabad near qaidabad karachi', '03123456789', '44123456789123', '8000', '01-01-2002');

-- --------------------------------------------------------

--
-- Table structure for table `hospitaladd`
--

CREATE TABLE `hospitaladd` (
  `address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hospitaladd`
--

INSERT INTO `hospitaladd` (`address`) VALUES
('Address: Liquat Medical Hospital Jamshoro');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('hello', 'hello'),
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `doctors` varchar(40) NOT NULL,
  `xray` varchar(40) NOT NULL,
  `counter` varchar(40) NOT NULL,
  `sweeper` varchar(40) NOT NULL,
  `guard` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`doctors`, `xray`, `counter`, `sweeper`, `guard`) VALUES
('5 doctors', '2 staff members', '3 counter members', '10 sweepers', '5 guards');

-- --------------------------------------------------------

--
-- Table structure for table `sweeper`
--

CREATE TABLE `sweeper` (
  `id` varchar(40) NOT NULL,
  `name` varchar(40) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact` varchar(60) NOT NULL,
  `nic` varchar(60) NOT NULL,
  `salary` varchar(40) NOT NULL,
  `date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sweeper`
--

INSERT INTO `sweeper` (`id`, `name`, `address`, `contact`, `nic`, `salary`, `date`) VALUES
('jak01', 'Jakab ', 'North ANzimabad gali number 2 near girls primiary school Karachi', '03038456757', '44848484848484', '5000', '01-01-2002'),
('naz02', 'Nazim', 'Muhala Karimabad gali number 1 near Mehmodabad Karachi', '03051230989', '40186712094581', '5000', '01-01-2002'),
('naz03', 'Nazis', 'Gohat Mehmodabad near Boys primiary school Karachi', '033333517878', '44024456712890', '5000', '01-02-2002'),
('gul04', 'Guhl Ahmed', 'Naseem Nager nera habib bank karachi', '03398912345', '44098789812345', '5000', '01-02-2002'),
('Aka05', 'Aktar Ahmed', 'Digroad near station karachi', '03050503948', '40404354651234', '5000', '02-012002'),
('bab06', 'Babar Ali', 'Muhala Karimabad gali number21 near Mehmodabad Karachi', '03311232123', '44044044567567', '5000', '02-02-2002'),
('nus07', 'Nusrat Khan', 'Muhala nasimabad near ghuar mandi road kurangi Karachi', '0334123423', '44055675675678', '5000', '01-012002'),
('bis08', 'Bisharat Ali', 'Gali number 2 huse number 2 kurangi Karachi', '03014561234', '40346575124546', '5000', '01-03-2002'),
('qas09', 'Qasim', 'Ghat Ghulam Near malir 15 Karachi', '03349090901', '44065734129054', '5000', '02-03-2002'),
('mar10', 'Mark', 'Mashi basti gali number 2 Karachi', '03019833456', '40486912345789', '5000', '02-03-2002');

-- --------------------------------------------------------

--
-- Table structure for table `xray`
--

CREATE TABLE `xray` (
  `id` varchar(20) NOT NULL,
  `name` varchar(40) NOT NULL,
  `nic` varchar(100) NOT NULL,
  `contact` varchar(60) NOT NULL,
  `address` varchar(100) NOT NULL,
  `salary` varchar(100) NOT NULL,
  `date` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `xray`
--

INSERT INTO `xray` (`id`, `name`, `nic`, `contact`, `address`, `salary`, `date`) VALUES
('za19a', 'Zohaib Ahmed', '44103456734564', '0334909098', 'Digroad gali no 2 house no 5 karachi', '15000', '12-10-2001'),
('bi12a', 'Bilal Hasan', '40123412327893', '03011287456', 'North Nazimabad near habib bank karachi', '15000', '15-11-2001');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

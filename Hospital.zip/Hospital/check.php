<html>
<head>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.0/css/bootstrap.min.css" integrity="sha384-SI27wrMjH3ZZ89r4o+fGIJtnzkAnFs3E4qz9DIYioCQ5l9Rd/7UAa8DHcaL8jkWt" crossorigin="anonymous">

</head>
<?php
include("func.php");
if (isset($_POST['check_search_submit'])) {
  $contact=$_POST['search'];
  $query="select * from doctorapp where contact='$contact'";
  $result=mysqli_query($con,$query);
echo "<div class='container-fluid'>
<div class='card'>
<div class='card-body'><a href='patient-details.php' class='btn btn-light' >Go Back</a></div>
<img src='images/3.jpg' height='350px' class='card-img-top' >
<div class='crad-body' style='background-color:#3498D8;color:#ffffff; '>
  <table class='table table-hover'>
  <thead>
    <tr>
  </th>
      <th >First Name</th>
      <th >Last Name</th>
      <th >Email Id</th>
      <th >Contact</th>
      <th >Doctor Appointment</th>
      <th >Date</th>
      <th >Payment</th>
    </tr>
  </thead>
  <tbody>";
  while ($row=mysqli_fetch_array($result)) {
  $fname=$row['fname'];
  $lname=$row['lname'];
  $email=$row['email'];
  $contact=$row['contact'];
  $docapp=$row['docapp'];
  $date=$row['date'];
  $paymnet=$row['payment'];
echo "<tr>
      <td>$fname</td>
      <td>$lname</td>
      <td>$email</td>
      <td>$contact</td>
      <td>$docapp</td>
       <td>$date</td>
      <td>$paymnet</td>
    </tr>";
}
echo "</tbody></table></div></div></div>";
}

?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.0/js/bootstrap.min.js" integrity="sha384-3qaqj0lc6sV/qpzrc1N5DC6i1VRn/HyX4qdPaiEFbn54VjQBEU341pvjz7Dv3n6P" crossorigin="anonymous"></script>
</body>
</html>
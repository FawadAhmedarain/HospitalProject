<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.0/css/bootstrap.min.css" integrity="sha384-SI27wrMjH3ZZ89r4o+fGIJtnzkAnFs3E4qz9DIYioCQ5l9Rd/7UAa8DHcaL8jkWt" crossorigin="anonymous">

</head>
<style type="text/css">
	#b1:hover{cursor: pointer;}
</style>
<body style="background:url('images/2.jpeg') no-repeat; background-size: cover">
<div  class="container" style="width: 400px;margin-top: 100px">
	<div class="card">
		<img src="images/1.jpg" class="card-img-top"><br>
<center><h3 class="card" style="color: #3252a8">Hospital Management System</h3></center>
		<div class="card-body">
	<form class="form-group" action="func.php" method="post">
		<label>Username :</label><br>
		<input type="text" name="username" class="form-control" placeholder="enter username"><br>
		<label>Password :</label><br>
		<input type="password" name="password" class="form-control" placeholder="enter password"><br>
		<input type="submit" name="login_submit" id="b1" class="btn btn-primary">
	</form>
	
		<div class="modal fade" id="modalLoginForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header text-center">
        <h4 class="modal-title w-100 font-weight-bold">Reset Password</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body mx-3">
      	<div class="card">
		<img src="images/1.jpg" class="card-img-top">
      <div class="modal-body mx-3">
        <div class="md-form mb-5">
          <i class="fas fa-envelope prefix grey-text"></i>
          <form action="func.php" method="post">
         <label data-error="wrong" data-success="right" for="defaultForm-email">Username</label>
          <input type="text" name="username" id="defaultForm-email" class="form-control validate"><br>
      <label data-error="wrong" data-success="right" for="defaultForm-pass">Rest Password</label>
           <input type="password" name="password" id="defaultForm-pass" class="form-control validate">
         
        </div>
      </div>
      <div class="modal-footer d-flex justify-content-center">
<input type="submit" name="reset" value="Resert Password" class="btn btn-primary">
    </form>
      </div></div></div>
    </div>
  </div>
</div>

<div class="text-center">
  <a href="" class="btn btn-default btn-rounded mb-4" data-toggle="modal" data-target="#modalLoginForm" style="color: #4272f5">Forgot Password?</a>
</div>

	
	</div>
	</div>
</div>




<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.0/js/bootstrap.min.js" integrity="sha384-3qaqj0lc6sV/qpzrc1N5DC6i1VRn/HyX4qdPaiEFbn54VjQBEU341pvjz7Dv3n6P" crossorigin="anonymous"></script>

</body>
</html>